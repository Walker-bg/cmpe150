
n = int(input())


# DO_NOT_EDIT_ANYTHING_ABOVE_THIS_LINE

# DO_NOT_EDIT_ANYTHING_BELOW_THIS_LINE

print(h(n))

